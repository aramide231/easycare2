import type { CategoryFieldConfig } from "../../../config/categoryFieldTypes";
import {
  BLOOD_SUGAR_OPTIONS,
  FHR_OPTIONS,
  RESPIRATION_OPTIONS,
  SPO2_OPTIONS,
  URINALYSIS_OPTIONS,
  VITAL_COMMENT_OPTIONS,
} from "../../../config/vitalFieldOptions";
import { CategoryFormWithHistory } from "../../category";

const vitalFields: CategoryFieldConfig[] = [
  {
    name: "temperature",
    label: "Temperature (°C)",
    tableLabel: "TEMP",
    required: true,
  },
  {
    name: "bloodPressure",
    label: "Blood Pressure (mmHg)",
    tableLabel: "B.P",
    required: true,
  },
  {
    name: "weight",
    label: "Weight (kg)",
    tableLabel: "WEIGHT",
    required: true,
  },
  {
    name: "height",
    label: "Height (cm)",
    tableLabel: "HEIGHT",
    required: true,
  },
  {
    name: "bloodSugar",
    label: "Blood Sugar",
    tableLabel: "B.S",
    type: "select",
    options: BLOOD_SUGAR_OPTIONS,
  },
  {
    name: "pulseRate",
    label: "Pulse Rate",
    tableLabel: "PULSE",
  },
  {
    name: "respiration",
    label: "Respiration",
    tableLabel: "RESP",
    type: "select",
    options: RESPIRATION_OPTIONS,
  },
  { name: "bmi", label: "Body Mass Index (BMI)", tableLabel: "BMI" },
  {
    name: "urinalysis",
    label: "Urinalysis",
    tableLabel: "UR",
    type: "select",
    options: URINALYSIS_OPTIONS,
  },
  {
    name: "spo2",
    label: "Peripheral Oxygen Saturation (SpO2)",
    tableLabel: "SPO₂",
    type: "select",
    options: SPO2_OPTIONS,
  },
  {
    name: "fhr",
    label: "Fetal Heart Rate (FHR)",
    tableLabel: "FHR",
    type: "select",
    options: FHR_OPTIONS,
  },
  {
    name: "comment",
    label: "Comments",
    tableLabel: "COMMENT",
    type: "select",
    options: VITAL_COMMENT_OPTIONS,
    showInTable: false,
  },
];

const vitalSignsTableColumns = [
  { key: "sn", label: "SN" },
  { key: "dateTime", label: "DATE | TIME" },
  { key: "patientType", label: "PATIENT TYPE" },
  { key: "temperature", label: "TEMP" },
  { key: "bloodPressure", label: "B.P" },
  { key: "weight", label: "WEIGHT" },
  { key: "height", label: "HEIGHT" },
  { key: "bmi", label: "BMI" },
];

export default function VitalSigns() {
  return (
    <CategoryFormWithHistory
      sectionName="VITAL SIGNS"
      fields={vitalFields}
      tableColumns={vitalSignsTableColumns}
      showSaveButton
    />
  );
}
